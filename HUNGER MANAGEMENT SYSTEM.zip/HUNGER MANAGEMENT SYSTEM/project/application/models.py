from django.db import models

# Create your models here.
class Register(models.Model):
    sno=models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    father=models.CharField(max_length=30)
    number=models.IntegerField()
    email=models.EmailField()
    item=models.CharField(max_length=100)
    address=models.CharField(max_length=50)
    location=models.CharField(max_length=60)
    donation=models.CharField(max_length=20)

    def __str__(self):
        return self.name


class Orgregister(models.Model):
    sno=models.AutoField(primary_key=True)
    name=models.CharField(max_length=30)
    number=models.IntegerField()
    email=models.EmailField()
    address=models.CharField(max_length=50)
    location=models.CharField(max_length=60)
    password=models.CharField(max_length=15)
    

    def __str__(self):
        return self.name
    