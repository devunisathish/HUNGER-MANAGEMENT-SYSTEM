from django.shortcuts import render,HttpResponse
from .models import Register
from .models import Orgregister
from django.contrib.auth import authenticate,login
from .models import Register
# Create your views here.

def dashboard(request):
    dashboard= Register.objects.all()
    return render(request,'dashboard.html',{'dashboard':dashboard})

def index(request):
    return render(request,'index.html')

def register(request):
    if request.method=="POST":
        name=request.POST.get("name")
        father=request.POST.get("father")
        number=request.POST.get("number")
        email=request.POST.get("email")
        item=request.POST.get("item")
        address=request.POST.get("address")
        location=request.POST.get("location")
        donation=request.POST.get("donation")


        #print(name,father,number,email,item,address,location) #this line for print the data into terminal
        
        query=Register(name=name,father=father,number=number,email=email,item=item,address=address,location=location,donation=donation)
        query.save()
        return HttpResponse("Response as been recorded")

    return render(request,'index.html')




def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def social(request):
    return render(request,'social.html')






def login(request):
    
    return render(request,'login.html')






def signup(request):
    return render(request,'signup.html')


def orgregister(request):
    if request.method=="POST":
        name=request.POST.get("name")
        number=request.POST.get("number")
        email=request.POST.get("email")
        address=request.POST.get("address")
        location=request.POST.get("location")
        password=request.POST.get("password")
        #print(name,number,email,address,location) #this line for print the data into terminal
        
        query=Orgregister(name=name,number=number,email=email,address=address,location=location,password=password)
        query.save()
        return HttpResponse("Response as been recorded")

    return render(request,'signup.html')


    